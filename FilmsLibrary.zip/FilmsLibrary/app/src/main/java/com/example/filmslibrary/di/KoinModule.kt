package com.example.filmslibrary.di

import com.example.filmslibrary.FilmsFragment.FilmsViewModel
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

val appModule = module {

    viewModel { FilmsViewModel(get()) }
}